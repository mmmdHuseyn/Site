document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.project-card, .expertise-card, .testimonial');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
            }
        });
    }, {
        threshold: 0.1
    });
    
    animatedElements.forEach(element => {
        element.style.animationPlayState = 'paused';
        observer.observe(element);
    });
    
    document.querySelector('.scroll-down').addEventListener('click', function() {
        window.scrollTo({
            top: document.querySelector('.projects-section').offsetTop,
            behavior: 'smooth'
        });
    });
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
    e.preventDefault();
    
    const targetId = this.getAttribute('href');
    if (targetId === "#") return;
    
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
        window.scrollTo({
        top: targetElement.offsetTop,
        behavior: 'smooth'
        });
    }
    });
});

const header = document.querySelector('header');
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
    header.classList.add('scrolled');
    } else {
    header.classList.remove('scrolled');
    }
});

const elements = document.querySelectorAll('.project-card, .expertise-card, .testimonial-card');
const animateOnScroll = () => {
    elements.forEach(el => {
    const position = el.getBoundingClientRect();
    if (position.top < window.innerHeight * 0.8) {
        if (!el.classList.contains('animated')) {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
        el.classList.add('animated');
        }
    }
    });
};

elements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
});

const cursorEffect = document.querySelector('.cursor-effect');
document.addEventListener('mousemove', (e) => {
    if (window.innerWidth > 768) {
    cursorEffect.style.opacity = '1';
    cursorEffect.style.left = e.clientX + 'px';
    cursorEffect.style.top = e.clientY + 'px';
    }
});

document.addEventListener('mouseleave', () => {
    cursorEffect.style.opacity = '0';
});

const projectCards = document.querySelectorAll('.project-card');
projectCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
    cursorEffect.style.opacity = '0.3';
    });
    
    card.addEventListener('mouseleave', () => {
    cursorEffect.style.opacity = '1';
    });
});

const navItems = document.querySelectorAll('nav li');
navItems.forEach(item => {
    item.addEventListener('click', () => {
    navItems.forEach(li => li.classList.remove('active'));
    item.classList.add('active');
    });
});

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('load', animateOnScroll);

window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});